package com.pushkar.ytdownloader

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File

/**
 * Runs one download at a time in the background with a progress notification,
 * so it keeps going when you leave the app.
 */
class DownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var lastNotifyAt = 0L
    private var title = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            YoutubeDL.destroyProcessById(PROCESS_ID)
            return START_NOT_STICKY
        }

        // Only one download at a time. If one is running, leave it alone.
        val running = DownloadRepository.state.value as? DownloadRepository.State.Running
        if (running != null) {
            startForegroundCompat(progressNotification(running.stage, running.progress))
            return START_NOT_STICKY
        }

        val url = intent?.getStringExtra(EXTRA_URL)
        val resolution = intent?.getIntExtra(EXTRA_RESOLUTION, -1) ?: -1
        title = intent?.getStringExtra(EXTRA_TITLE) ?: "Video"

        startForegroundCompat(progressNotification("Starting…", -1f))

        // Check the link again here, in case anything other than our screen started us.
        val valid = url?.let { UrlValidator.check(it) as? UrlValidator.Result.Valid }
        if (valid == null) {
            DownloadRepository.set(DownloadRepository.State.Failed("Invalid link."))
            stopSelfCompat()
            return START_NOT_STICKY
        }

        val choice = if (resolution > 0) DownloadChoice.Video(resolution) else DownloadChoice.AudioMp3
        DownloadRepository.set(DownloadRepository.State.Running(title, -1f, -1, "Starting…"))
        scope.launch { runDownload(valid.url, choice) }
        return START_NOT_STICKY
    }

    private fun runDownload(url: String, choice: DownloadChoice) {
        val workDir = File(cacheDir, "work").apply {
            deleteRecursively()
            mkdirs()
        }
        try {
            val request = YoutubeDLRequest(url)
            Engine.applyCommonOptions(this, request)
            request.addOption("-o", "${workDir.absolutePath}/%(title).150B [%(id)s].%(ext)s")
            request.addOption("--no-mtime")
            request.addOption("--embed-metadata")
            request.addOption("--concurrent-fragments", "4")

            when (choice) {
                is DownloadChoice.Video -> {
                    // Best video at or below the chosen quality, plus best audio.
                    // Prefer H.264 + AAC for playback on every phone when available.
                    request.addOption("-f", "bv*+ba/b")
                    request.addOption("-S", "res:${choice.resolution},vcodec:h264,acodec:aac")
                    request.addOption("--merge-output-format", "mp4/mkv")
                }
                DownloadChoice.AudioMp3 -> {
                    request.addOption("-f", "ba/b")
                    request.addOption("-x")
                    request.addOption("--audio-format", "mp3")
                    request.addOption("--audio-quality", "0")
                }
            }

            YoutubeDL.execute(request, PROCESS_ID) { progress, eta, line ->
                onProgress(progress, eta, line)
            }

            val output = workDir.listFiles()
                ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                ?.maxByOrNull { it.length() }
                ?: throw IllegalStateException("The download finished but no file was found.")

            updateStage("Saving to Downloads…", 100f, 0)
            val location = MediaSaver.save(this, output)
            val savedName = MediaSaver.safeName(output.name)
            DownloadRepository.set(DownloadRepository.State.Done(savedName, location))
            notifyFinished("Download complete", "$savedName saved to $location")
        } catch (e: YoutubeDL.CanceledException) {
            DownloadRepository.set(DownloadRepository.State.Cancelled)
            NotificationManagerCompat.from(this).cancel(NOTIFICATION_PROGRESS)
        } catch (e: Exception) {
            val message = friendlyError(e.message)
            DownloadRepository.set(DownloadRepository.State.Failed(message))
            notifyFinished("Download failed", message)
        } finally {
            workDir.deleteRecursively()
            stopSelfCompat()
        }
    }

    private fun onProgress(progress: Float, eta: Long, line: String) {
        val stage = when {
            line.startsWith("[Merger]") -> "Merging video and audio…"
            line.startsWith("[ExtractAudio]") -> "Converting to MP3…"
            line.startsWith("[Metadata]") -> "Adding details…"
            line.startsWith("[download]") -> "Downloading…"
            line.startsWith("[youtube]") || line.startsWith("[info]") -> "Preparing…"
            else -> null
        }
        val current = DownloadRepository.state.value as? DownloadRepository.State.Running
        updateStage(stage ?: current?.stage ?: "Downloading…", progress, eta)
    }

    private fun updateStage(stage: String, progress: Float, eta: Long) {
        DownloadRepository.set(DownloadRepository.State.Running(title, progress, eta, stage))
        val now = System.currentTimeMillis()
        if (now - lastNotifyAt > 700) {
            lastNotifyAt = now
            notifyIfAllowed(NOTIFICATION_PROGRESS, progressNotification(stage, progress))
        }
    }

    private fun progressNotification(stage: String, progress: Float): Notification {
        val cancelIntent = PendingIntent.getService(
            this, 1,
            Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, App.CHANNEL_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(stage)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent())
            .addAction(0, "Cancel", cancelIntent)
        if (progress in 0f..100f) {
            builder.setProgress(100, progress.toInt(), false)
        } else {
            builder.setProgress(0, 0, true)
        }
        return builder.build()
    }

    private fun notifyFinished(heading: String, text: String) {
        NotificationManagerCompat.from(this).cancel(NOTIFICATION_PROGRESS)
        val notification = NotificationCompat.Builder(this, App.CHANNEL_DONE)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(heading)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
        notifyIfAllowed(NOTIFICATION_DONE, notification)
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    @SuppressLint("MissingPermission") // checked on the next lines
    private fun notifyIfAllowed(id: Int, notification: Notification) {
        val allowed = Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        if (allowed) NotificationManagerCompat.from(this).notify(id, notification)
    }

    private fun startForegroundCompat(notification: Notification) {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        } else 0
        ServiceCompat.startForeground(this, NOTIFICATION_PROGRESS, notification, type)
    }

    private fun stopSelfCompat() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        YoutubeDL.destroyProcessById(PROCESS_ID)
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val PROCESS_ID = "download"
        private const val ACTION_CANCEL = "com.pushkar.ytdownloader.CANCEL"
        private const val EXTRA_URL = "url"
        private const val EXTRA_TITLE = "title"
        private const val EXTRA_RESOLUTION = "resolution"
        private const val NOTIFICATION_PROGRESS = 1
        private const val NOTIFICATION_DONE = 2

        fun start(context: Context, url: String, title: String, choice: DownloadChoice) {
            val intent = Intent(context, DownloadService::class.java)
                .putExtra(EXTRA_URL, url)
                .putExtra(EXTRA_TITLE, title)
                .putExtra(
                    EXTRA_RESOLUTION,
                    if (choice is DownloadChoice.Video) choice.resolution else -1
                )
            ContextCompat.startForegroundService(context, intent)
        }

        fun cancel(context: Context) {
            YoutubeDL.destroyProcessById(PROCESS_ID)
        }

        /** Turns engine errors into plain messages. */
        fun friendlyError(raw: String?): String {
            val text = raw.orEmpty()
            return when {
                text.contains("confirm you", ignoreCase = true) && text.contains("bot", ignoreCase = true) ->
                    "YouTube asked for a bot check. Wait a while and try again, or switch the engine to Nightly."
                text.contains("Private video", ignoreCase = true) -> "This video is private."
                text.contains("age", ignoreCase = true) && text.contains("sign in", ignoreCase = true) ->
                    "This video is age-restricted and needs a signed-in account."
                text.contains("Video unavailable", ignoreCase = true) -> "This video is unavailable."
                text.contains("Unable to resolve host", ignoreCase = true) ||
                        text.contains("Failed to resolve", ignoreCase = true) ||
                        text.contains("Network is unreachable", ignoreCase = true) ->
                    "No internet connection."
                text.contains("No space left", ignoreCase = true) -> "Your phone is out of storage."
                text.isBlank() -> "Something went wrong. Try updating the engine."
                else -> text.lineSequence().map { it.trim() }
                    .lastOrNull { it.startsWith("ERROR") }
                    ?.removePrefix("ERROR:")?.trim()
                    ?: "Something went wrong. Try updating the engine."
            }
        }
    }
}
