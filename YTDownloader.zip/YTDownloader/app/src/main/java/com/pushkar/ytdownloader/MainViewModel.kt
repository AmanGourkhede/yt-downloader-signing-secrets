package com.pushkar.ytdownloader

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    sealed interface FetchState {
        data object Idle : FetchState
        data object Loading : FetchState
        data class Loaded(val details: VideoDetails) : FetchState
        data class Error(val message: String) : FetchState
    }

    private val _link = MutableStateFlow("")
    val link: StateFlow<String> = _link.asStateFlow()

    private val _fetch = MutableStateFlow<FetchState>(FetchState.Idle)
    val fetch: StateFlow<FetchState> = _fetch.asStateFlow()

    private val _engineMessage = MutableStateFlow<String?>(null)
    val engineMessage: StateFlow<String?> = _engineMessage.asStateFlow()

    private val _channel = MutableStateFlow(EngineUpdater.channel(app))
    val channel: StateFlow<EngineUpdater.Channel> = _channel.asStateFlow()

    val engineState = Engine.state
    val engineVersion = EngineUpdater.version
    val engineUpdating = EngineUpdater.updating
    val download = DownloadRepository.state

    init {
        EngineUpdater.loadVersion(app)
    }

    fun onLinkChange(value: String) {
        _link.value = value
        if (_fetch.value is FetchState.Error) _fetch.value = FetchState.Idle
    }

    /** Text shared from another app (e.g. the YouTube app's Share button). */
    fun onSharedText(text: String) {
        _link.value = UrlValidator.fromSharedText(text)
        fetchDetails()
    }

    fun fetchDetails() {
        val result = UrlValidator.check(_link.value)
        if (result is UrlValidator.Result.Invalid) {
            _fetch.value = FetchState.Error(result.reason)
            return
        }
        val url = (result as UrlValidator.Result.Valid).url
        _fetch.value = FetchState.Loading
        viewModelScope.launch {
            // Wait until the engine has finished starting.
            val engine = Engine.state.first { it !is Engine.State.Starting }
            if (engine is Engine.State.Failed) {
                _fetch.value = FetchState.Error("Engine error: ${engine.message}")
                return@launch
            }
            _fetch.value = try {
                val details = withContext(Dispatchers.IO) {
                    VideoDetailsFetcher.fetch(getApplication(), url)
                }
                if (details.qualities.isEmpty() && details.audioSizeBytes == 0L) {
                    FetchState.Error("No downloadable formats found. Try updating the engine.")
                } else {
                    FetchState.Loaded(details)
                }
            } catch (e: Exception) {
                FetchState.Error(DownloadService.friendlyError(e.message))
            }
        }
    }

    fun startDownload(details: VideoDetails, choice: DownloadChoice) {
        if (DownloadRepository.isBusy) return
        if (EngineUpdater.updating.value) {
            _engineMessage.value = "Wait a moment, the engine is updating."
            return
        }
        DownloadService.start(getApplication(), details.url, details.title, choice)
    }

    fun cancelDownload() {
        DownloadService.cancel(getApplication())
    }

    fun dismissResult() {
        DownloadRepository.clearFinished()
    }

    fun updateEngine() {
        viewModelScope.launch {
            _engineMessage.value = when (val r = EngineUpdater.update(getApplication())) {
                is EngineUpdater.Result.Updated -> "Engine updated to ${r.version}."
                is EngineUpdater.Result.UpToDate -> "Engine is up to date (${r.version})."
                is EngineUpdater.Result.Failed -> r.reason
            }
        }
    }

    fun setNightly(enabled: Boolean) {
        val channel = if (enabled) EngineUpdater.Channel.NIGHTLY else EngineUpdater.Channel.STABLE
        EngineUpdater.setChannel(getApplication(), channel)
        _channel.value = channel
        updateEngine()
    }
}
