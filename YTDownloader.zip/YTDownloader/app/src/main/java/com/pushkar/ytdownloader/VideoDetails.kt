package com.pushkar.ytdownloader

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.mapper.VideoInfo
import kotlin.math.min

/** What the user can pick for one video. */
data class VideoDetails(
    val url: String,
    val title: String,
    val uploader: String?,
    val durationSeconds: Int,
    val qualities: List<Quality>,
    val audioSizeBytes: Long,
)

/** A video quality, e.g. 1080p, with an approximate total size (0 if unknown). */
data class Quality(val resolution: Int, val approxBytes: Long) {
    val label: String
        get() = when (resolution) {
            2160 -> "2160p (4K)"
            1440 -> "1440p (2K)"
            else -> "${resolution}p"
        }
}

/** The two kinds of download the app offers. */
sealed interface DownloadChoice {
    data class Video(val resolution: Int) : DownloadChoice
    data object AudioMp3 : DownloadChoice
}

object VideoDetailsFetcher {

    const val PROCESS_ID = "fetch-info"

    fun fetch(context: Context, url: String): VideoDetails {
        val request = YoutubeDLRequest(url)
        Engine.applyCommonOptions(context, request)
        val info: VideoInfo = YoutubeDL.getInfo(request)
        return toDetails(url, info)
    }

    private fun toDetails(url: String, info: VideoInfo): VideoDetails {
        val formats = info.formats.orEmpty()

        fun size(f: com.yausername.youtubedl_android.mapper.VideoFormat): Long =
            if (f.fileSize > 0) f.fileSize else f.fileSizeApproximate

        val audioOnly = formats.filter { it.vcodec == "none" && it.acodec != null && it.acodec != "none" }
        val bestAudioSize = audioOnly.maxOfOrNull { size(it) } ?: 0L

        // "Resolution" uses the smaller side, so vertical Shorts show as 1080p, not 1920p.
        val byResolution = formats
            .filter { it.vcodec != null && it.vcodec != "none" && it.height > 0 }
            .groupBy { f -> if (f.width > 0) min(f.width, f.height) else f.height }

        val qualities = byResolution
            .filterKeys { it >= 144 }
            .map { (res, list) ->
                val videoSize = list.maxOfOrNull { size(it) } ?: 0L
                val total = if (videoSize > 0) videoSize + bestAudioSize else 0L
                Quality(res, total)
            }
            .sortedByDescending { it.resolution }

        return VideoDetails(
            url = url,
            title = info.title ?: "Untitled video",
            uploader = info.uploader,
            durationSeconds = info.duration,
            qualities = qualities,
            audioSizeBytes = bestAudioSize,
        )
    }
}
