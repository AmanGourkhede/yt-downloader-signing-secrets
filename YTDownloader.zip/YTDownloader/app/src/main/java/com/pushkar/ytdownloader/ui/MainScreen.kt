package com.pushkar.ytdownloader.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pushkar.ytdownloader.DownloadChoice
import com.pushkar.ytdownloader.DownloadRepository
import com.pushkar.ytdownloader.Engine
import com.pushkar.ytdownloader.EngineUpdater
import com.pushkar.ytdownloader.MainViewModel
import com.pushkar.ytdownloader.VideoDetails
import java.util.Locale

@Composable
fun MainScreen(vm: MainViewModel) {
    val link by vm.link.collectAsStateWithLifecycle()
    val fetch by vm.fetch.collectAsStateWithLifecycle()
    val download by vm.download.collectAsStateWithLifecycle()
    val engine by vm.engineState.collectAsStateWithLifecycle()
    val version by vm.engineVersion.collectAsStateWithLifecycle()
    val updating by vm.engineUpdating.collectAsStateWithLifecycle()
    val engineMessage by vm.engineMessage.collectAsStateWithLifecycle()
    val channel by vm.channel.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val focus = LocalFocusManager.current

    // Remember what the user tapped while we ask for permissions.
    var pending by remember { mutableStateOf<Pair<VideoDetails, DownloadChoice>?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val p = pending
        pending = null
        if (p == null) return@rememberLauncherForActivityResult
        // Storage permission is required only on Android 9 and older.
        val storageOk = Build.VERSION.SDK_INT >= 29 ||
                results[Manifest.permission.WRITE_EXTERNAL_STORAGE] == true ||
                ContextCompat.checkSelfPermission(
                    context, Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
        if (storageOk) vm.startDownload(p.first, p.second)
    }

    fun requestAndDownload(details: VideoDetails, choice: DownloadChoice) {
        val needed = buildList {
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            if (Build.VERSION.SDK_INT < 29) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }.filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isEmpty()) {
            vm.startDownload(details, choice)
        } else {
            pending = details to choice
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                "YT Downloader",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.SemiBold
            )

            if (engine is Engine.State.Starting) {
                Text(
                    "Setting up the engine (first launch takes a few seconds)…",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            (engine as? Engine.State.Failed)?.let {
                Text(
                    "Engine error: ${it.message}",
                    color = MaterialTheme.colorScheme.error
                )
            }

            OutlinedTextField(
                value = link,
                onValueChange = vm::onLinkChange,
                label = { Text("YouTube link") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Uri,
                    imeAction = ImeAction.Go
                ),
                keyboardActions = KeyboardActions(onGo = {
                    focus.clearFocus()
                    vm.fetchDetails()
                })
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    clipboard.getText()?.text?.let { vm.onLinkChange(it.trim()) }
                }) { Text("Paste") }
                Button(
                    onClick = {
                        focus.clearFocus()
                        vm.fetchDetails()
                    },
                    enabled = fetch !is MainViewModel.FetchState.Loading
                ) { Text("Fetch") }
            }

            when (val f = fetch) {
                MainViewModel.FetchState.Idle -> Unit
                MainViewModel.FetchState.Loading -> Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 3.dp)
                    Text("Getting video details…")
                }
                is MainViewModel.FetchState.Error -> Text(
                    f.message,
                    color = MaterialTheme.colorScheme.error
                )
                is MainViewModel.FetchState.Loaded -> VideoCard(
                    details = f.details,
                    busy = download is DownloadRepository.State.Running || updating,
                    onChoose = { choice -> requestAndDownload(f.details, choice) }
                )
            }

            DownloadStatus(
                state = download,
                onCancel = vm::cancelDownload,
                onDismiss = vm::dismissResult
            )

            HorizontalDivider()

            EngineSection(
                version = version,
                updating = updating,
                message = engineMessage,
                nightly = channel == EngineUpdater.Channel.NIGHTLY,
                onUpdate = vm::updateEngine,
                onNightlyChange = vm::setNightly
            )

            Spacer(Modifier.height(8.dp))
            Text(
                "Files are saved to Downloads/YT Downloader. Only download videos you have the right to save.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun VideoCard(
    details: VideoDetails,
    busy: Boolean,
    onChoose: (DownloadChoice) -> Unit,
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                details.title,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            val sub = listOfNotNull(details.uploader, formatDuration(details.durationSeconds))
                .joinToString("  ·  ")
            if (sub.isNotBlank()) {
                Text(sub, style = MaterialTheme.typography.bodySmall)
            }

            Text("Video (with audio)", fontWeight = FontWeight.SemiBold)
            details.qualities.forEach { q ->
                OutlinedButton(
                    onClick = { onChoose(DownloadChoice.Video(q.resolution)) },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(q.label, modifier = Modifier.weight(1f))
                    formatSize(q.approxBytes)?.let { Text(it) }
                }
            }

            Text("Audio only", fontWeight = FontWeight.SemiBold)
            OutlinedButton(
                onClick = { onChoose(DownloadChoice.AudioMp3) },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("MP3 (best quality)", modifier = Modifier.weight(1f))
                formatSize(details.audioSizeBytes)?.let { Text(it) }
            }
        }
    }
}

@Composable
private fun DownloadStatus(
    state: DownloadRepository.State,
    onCancel: () -> Unit,
    onDismiss: () -> Unit,
) {
    if (state is DownloadRepository.State.Idle) return
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when (state) {
                is DownloadRepository.State.Running -> {
                    Text(state.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.SemiBold)
                    if (state.progress in 0f..100f) {
                        LinearProgressIndicator(
                            progress = { state.progress / 100f },
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                    val eta = if (state.etaSeconds > 0) "  ·  ${formatDuration(state.etaSeconds.toInt())} left" else ""
                    val pct = if (state.progress in 0f..100f) "  ·  ${state.progress.toInt()}%" else ""
                    Text("${state.stage}$pct$eta", style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = onCancel) { Text("Cancel") }
                }
                is DownloadRepository.State.Done -> {
                    Text("Saved", fontWeight = FontWeight.SemiBold)
                    Text("${state.fileName}\nin ${state.location}", style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = onDismiss) { Text("OK") }
                }
                is DownloadRepository.State.Failed -> {
                    Text("Download failed", fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.error)
                    Text(state.message, style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = onDismiss) { Text("OK") }
                }
                DownloadRepository.State.Cancelled -> {
                    Text("Download cancelled")
                    TextButton(onClick = onDismiss) { Text("OK") }
                }
                DownloadRepository.State.Idle -> Unit
            }
        }
    }
}

@Composable
private fun EngineSection(
    version: String?,
    updating: Boolean,
    message: String?,
    nightly: Boolean,
    onUpdate: () -> Unit,
    onNightlyChange: (Boolean) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Engine", fontWeight = FontWeight.SemiBold)
        Text(
            "yt-dlp ${version ?: "(built-in, updating on first launch)"}",
            style = MaterialTheme.typography.bodySmall
        )
        Text(
            "Updates itself once a day. Every update is checksum-verified.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onUpdate, enabled = !updating) {
                Text(if (updating) "Updating…" else "Update now")
            }
            if (updating) {
                Spacer(Modifier.size(12.dp))
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Use Nightly engine")
                Text(
                    "Gets YouTube fixes faster. Turn on if downloads stop working.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked = nightly, onCheckedChange = onNightlyChange, enabled = !updating)
        }
        message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    }
}

private fun formatDuration(seconds: Int): String? {
    if (seconds <= 0) return null
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%d:%02d", m, s)
}

private fun formatSize(bytes: Long): String? {
    if (bytes <= 0) return null
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1024) String.format(Locale.US, "~%.1f GB", mb / 1024)
    else String.format(Locale.US, "~%.0f MB", mb)
}
