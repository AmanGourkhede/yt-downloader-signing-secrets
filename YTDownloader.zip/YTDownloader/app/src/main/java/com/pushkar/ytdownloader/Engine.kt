package com.pushkar.ytdownloader

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

/**
 * Starts the download engine (Python + yt-dlp + FFmpeg) once per app launch
 * and keeps it up to date in the background.
 */
object Engine {

    sealed interface State {
        data object Starting : State
        data object Ready : State
        data class Failed(val message: String) : State
    }

    private val _state = MutableStateFlow<State>(State.Starting)
    val state: StateFlow<State> = _state.asStateFlow()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var started = false

    fun start(context: Context) {
        if (started) return
        started = true
        val app = context.applicationContext
        scope.launch {
            try {
                YoutubeDL.init(app)
                FFmpeg.init(app)
                _state.value = State.Ready
            } catch (e: Exception) {
                _state.value = State.Failed(e.message ?: "The download engine could not start.")
                return@launch
            }
            // Silent daily update so YouTube changes do not break the app.
            EngineUpdater.updateIfDue(app)
        }
    }

    /** QuickJS ships inside the APK as a native file, so Android allows running it. */
    private fun quickJsPath(context: Context): String? {
        val file = File(context.applicationInfo.nativeLibraryDir, "libqjs.so")
        return if (file.exists()) file.absolutePath else null
    }

    /** Options added to every engine run. */
    fun applyCommonOptions(context: Context, request: YoutubeDLRequest) {
        // Never read config files from storage; only our own options are used.
        request.addOption("--ignore-config")
        // One video per link, even if the link is part of a playlist.
        request.addOption("--no-playlist")
        // YouTube needs a JavaScript engine to unlock video formats.
        quickJsPath(context)?.let { request.addOption("--js-runtimes", "quickjs:$it") }
    }
}
