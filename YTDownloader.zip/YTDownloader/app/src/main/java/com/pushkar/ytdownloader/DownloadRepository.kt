package com.pushkar.ytdownloader

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Shared download status, written by the service and shown by the screen. */
object DownloadRepository {

    sealed interface State {
        data object Idle : State
        data class Running(
            val title: String,
            val progress: Float, // 0..100, or -1 when unknown
            val etaSeconds: Long,
            val stage: String,
        ) : State

        data class Done(val fileName: String, val location: String) : State
        data class Failed(val message: String) : State
        data object Cancelled : State
    }

    private val _state = MutableStateFlow<State>(State.Idle)
    val state: StateFlow<State> = _state.asStateFlow()

    val isBusy: Boolean get() = _state.value is State.Running

    fun set(state: State) {
        _state.value = state
    }

    fun clearFinished() {
        if (!isBusy) _state.value = State.Idle
    }
}
