package com.pushkar.ytdownloader

import java.net.URI

/**
 * Accepts only real YouTube links and rebuilds them in a clean https form.
 * Anything else is rejected before it ever reaches the download engine.
 */
object UrlValidator {

    private val allowedHosts = setOf(
        "youtube.com",
        "www.youtube.com",
        "m.youtube.com",
        "music.youtube.com",
        "youtu.be",
        "www.youtu.be",
    )

    private const val MAX_LENGTH = 2048

    sealed interface Result {
        data class Valid(val url: String) : Result
        data class Invalid(val reason: String) : Result
    }

    /** Pulls the first link out of shared text (the YouTube app shares extra words). */
    fun fromSharedText(text: String): String {
        return Regex("""https?://\S+""").find(text)?.value ?: text.trim()
    }

    fun check(raw: String): Result {
        val input = raw.trim()
        if (input.isEmpty()) return Result.Invalid("Paste a YouTube link first.")
        if (input.length > MAX_LENGTH) return Result.Invalid("That link is too long.")
        if (input.any { it.isWhitespace() || it.isISOControl() }) {
            return Result.Invalid("That doesn't look like a single link.")
        }

        val uri = try {
            URI(input)
        } catch (e: Exception) {
            return Result.Invalid("That doesn't look like a valid link.")
        }

        val scheme = uri.scheme?.lowercase()
        if (scheme != "https" && scheme != "http") {
            return Result.Invalid("Only YouTube web links are supported.")
        }
        if (uri.rawUserInfo != null) return Result.Invalid("That link is not allowed.")
        if (uri.port != -1 && uri.port != 443 && uri.port != 80) {
            return Result.Invalid("That link is not allowed.")
        }

        val host = uri.host?.lowercase() ?: return Result.Invalid("That link has no website.")
        if (host !in allowedHosts) return Result.Invalid("Only YouTube links are supported.")

        val path = uri.rawPath.orEmpty()
        if (path.startsWith("/playlist")) {
            return Result.Invalid("Playlists aren't supported. Open one video and share that.")
        }

        // Rebuild as https, dropping any port, user info, or fragment.
        val query = uri.rawQuery?.let { "?$it" }.orEmpty()
        return Result.Valid("https://$host$path$query")
    }
}
