package com.pushkar.ytdownloader

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.URL
import java.security.MessageDigest
import javax.net.ssl.HttpsURLConnection

/**
 * Keeps yt-dlp (the part that understands YouTube) up to date.
 *
 * Security steps for every update:
 *  1. Release info comes from GitHub over HTTPS only.
 *  2. Files are accepted only from github.com/yt-dlp/... release links.
 *  3. The new file's SHA-256 checksum must match the official SHA2-256SUMS file.
 *  4. The new engine must pass a self-test, otherwise the old one is restored.
 */
object EngineUpdater {

    enum class Channel(val label: String, val apiUrl: String) {
        STABLE("Stable", "https://api.github.com/repos/yt-dlp/yt-dlp/releases/latest"),
        NIGHTLY("Nightly", "https://api.github.com/repos/yt-dlp/yt-dlp-nightly-builds/releases/latest"),
    }

    sealed interface Result {
        data class Updated(val version: String) : Result
        data class UpToDate(val version: String) : Result
        data class Failed(val reason: String) : Result
    }

    private const val PREFS = "engine_updater"
    private const val KEY_VERSION = "version"
    private const val KEY_LAST_CHECK = "last_check"
    private const val KEY_CHANNEL = "channel"

    private const val CHECK_INTERVAL_MS = 24L * 60 * 60 * 1000
    private const val MAX_JSON_BYTES = 2L * 1024 * 1024
    private const val MAX_SUMS_BYTES = 1L * 1024 * 1024
    private const val MAX_BINARY_BYTES = 60L * 1024 * 1024

    private const val BINARY_NAME = "yt-dlp"
    private const val SUMS_NAME = "SHA2-256SUMS"

    private val mutex = Mutex()

    private val _updating = MutableStateFlow(false)
    val updating: StateFlow<Boolean> = _updating.asStateFlow()

    private val _version = MutableStateFlow<String?>(null)
    val version: StateFlow<String?> = _version.asStateFlow()

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun loadVersion(context: Context) {
        _version.value = prefs(context).getString(KEY_VERSION, null)
    }

    fun channel(context: Context): Channel {
        val name = prefs(context).getString(KEY_CHANNEL, Channel.STABLE.name)
        return Channel.entries.firstOrNull { it.name == name } ?: Channel.STABLE
    }

    fun setChannel(context: Context, channel: Channel) {
        prefs(context).edit().putString(KEY_CHANNEL, channel.name).apply()
    }

    /** Called on app start. Checks at most once a day. */
    suspend fun updateIfDue(context: Context) {
        loadVersion(context)
        val last = prefs(context).getLong(KEY_LAST_CHECK, 0L)
        val neverUpdated = prefs(context).getString(KEY_VERSION, null) == null
        if (!neverUpdated && System.currentTimeMillis() - last < CHECK_INTERVAL_MS) return
        update(context)
    }

    suspend fun update(context: Context): Result = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (DownloadRepository.isBusy) {
                return@withLock Result.Failed("Wait for the current download to finish.")
            }
            _updating.value = true
            try {
                runUpdate(context.applicationContext)
            } catch (e: Exception) {
                Result.Failed(e.message ?: "Update failed. Check your internet connection.")
            } finally {
                _updating.value = false
            }
        }
    }

    private fun runUpdate(context: Context): Result {
        val channel = channel(context)
        val release = JSONObject(httpsGetText(channel.apiUrl, MAX_JSON_BYTES))
        val tag = release.getString("tag_name")

        val engineFile = engineFile(context)
        val installed = prefs(context).getString(KEY_VERSION, null)
        if (installed == tag && engineFile.exists()) {
            markChecked(context)
            return Result.UpToDate(tag)
        }

        // Find the two files we need in this release.
        var binaryUrl: String? = null
        var sumsUrl: String? = null
        val assets = release.getJSONArray("assets")
        for (i in 0 until assets.length()) {
            val asset = assets.getJSONObject(i)
            when (asset.getString("name")) {
                BINARY_NAME -> binaryUrl = asset.getString("browser_download_url")
                SUMS_NAME -> sumsUrl = asset.getString("browser_download_url")
            }
        }
        if (binaryUrl == null || sumsUrl == null) {
            return Result.Failed("The latest release is missing files. Try again later.")
        }
        requireTrustedReleaseUrl(binaryUrl)
        requireTrustedReleaseUrl(sumsUrl)

        // Expected checksum from the official list.
        val expectedHash = httpsGetText(sumsUrl, MAX_SUMS_BYTES)
            .lineSequence()
            .map { it.trim().split(Regex("\\s+")) }
            .firstOrNull { it.size == 2 && it[1].removePrefix("*") == BINARY_NAME }
            ?.get(0)?.lowercase()
            ?: return Result.Failed("Could not find the checksum for the new engine.")

        // Download to a temporary file while computing its checksum.
        val dir = engineFile.parentFile ?: throw IOException("Engine folder missing.")
        dir.mkdirs()
        val temp = File(dir, "$BINARY_NAME.download")
        val actualHash = downloadWithSha256(binaryUrl, temp, MAX_BINARY_BYTES)
        if (!MessageDigest.isEqual(actualHash.toByteArray(), expectedHash.toByteArray())) {
            temp.delete()
            return Result.Failed("Security check failed: the downloaded engine was not genuine. Nothing was changed.")
        }

        // Swap in the new engine, keeping a backup of the old one.
        val backup = File(dir, "$BINARY_NAME.backup")
        backup.delete()
        if (engineFile.exists() && !engineFile.renameTo(backup)) {
            temp.delete()
            return Result.Failed("Could not replace the old engine.")
        }
        if (!temp.renameTo(engineFile)) {
            backup.renameTo(engineFile)
            temp.delete()
            return Result.Failed("Could not install the new engine.")
        }

        // Self-test. If the new engine does not run, put the old one back.
        if (!selfTest(context)) {
            engineFile.delete()
            if (backup.exists()) backup.renameTo(engineFile)
            return Result.Failed("The new engine failed its self-test, so the old one was kept.")
        }
        backup.delete()

        prefs(context).edit().putString(KEY_VERSION, tag).apply()
        _version.value = tag
        markChecked(context)
        return Result.Updated(tag)
    }

    private fun markChecked(context: Context) {
        prefs(context).edit().putLong(KEY_LAST_CHECK, System.currentTimeMillis()).apply()
    }

    /** Same location the engine library loads yt-dlp from. */
    private fun engineFile(context: Context): File {
        val base = File(context.noBackupFilesDir, YoutubeDL.baseName)
        return File(File(base, YoutubeDL.ytdlpDirName), YoutubeDL.ytdlpBin)
    }

    private fun selfTest(context: Context): Boolean {
        return try {
            val request = YoutubeDLRequest(emptyList<String>())
            request.addOption("--ignore-config")
            request.addOption("--version")
            val response = YoutubeDL.execute(request)
            response.exitCode == 0 && response.out.isNotBlank()
        } catch (e: Exception) {
            false
        }
    }

    /** Only official yt-dlp release downloads on github.com are accepted. */
    private fun requireTrustedReleaseUrl(url: String) {
        val parsed = URL(url)
        val ok = parsed.protocol == "https" &&
                parsed.host == "github.com" &&
                parsed.path.startsWith("/yt-dlp/")
        if (!ok) throw IOException("Blocked an untrusted download link.")
    }

    private fun open(url: String): HttpsURLConnection {
        val connection = URL(url).openConnection() as? HttpsURLConnection
            ?: throw IOException("Only secure (HTTPS) connections are allowed.")
        connection.connectTimeout = 15_000
        connection.readTimeout = 30_000
        connection.instanceFollowRedirects = true
        connection.setRequestProperty("User-Agent", "YTDownloader-Android")
        connection.setRequestProperty("Accept", "application/vnd.github+json, application/octet-stream")
        val code = connection.responseCode
        // A redirect must never downgrade to plain HTTP.
        if (connection.url.protocol != "https") {
            connection.disconnect()
            throw IOException("Blocked an insecure redirect.")
        }
        if (code != 200) {
            connection.disconnect()
            throw IOException("Server answered $code. Try again later.")
        }
        return connection
    }

    private fun httpsGetText(url: String, maxBytes: Long): String {
        val connection = open(url)
        try {
            connection.inputStream.use { input ->
                val out = ByteArrayOutputStream()
                copyLimited(input, maxBytes) { buffer, count -> out.write(buffer, 0, count) }
                return out.toString("UTF-8")
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun downloadWithSha256(url: String, target: File, maxBytes: Long): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val connection = open(url)
        try {
            connection.inputStream.use { input ->
                target.outputStream().use { output ->
                    copyLimited(input, maxBytes) { buffer, count ->
                        digest.update(buffer, 0, count)
                        output.write(buffer, 0, count)
                    }
                }
            }
        } catch (e: Exception) {
            target.delete()
            throw e
        } finally {
            connection.disconnect()
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private inline fun copyLimited(
        input: InputStream,
        maxBytes: Long,
        sink: (ByteArray, Int) -> Unit,
    ) {
        val buffer = ByteArray(64 * 1024)
        var total = 0L
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            if (total > maxBytes) throw IOException("Download was larger than expected and was stopped.")
            sink(buffer, count)
        }
    }
}
