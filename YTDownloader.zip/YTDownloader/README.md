# YT Downloader (Android)

A simple, private YouTube downloader for your own phone.

* Paste a link, or tap **Share** in the YouTube app and choose **YT Downloader**
* Pick any quality (144p up to 4K) with audio merged in, or **MP3** audio only
* Downloads keep running in the background with a notification
* Files go to **Downloads/YT Downloader**
* No ads, no tracking, no accounts

---

## Get the APK without Android Studio (GitHub builds it for you)

You only do steps 1 to 4 once.

1. **Create a GitHub account** at github.com if you don't have one.
2. **Create a new repository**: click **+** (top right) > **New repository**. Name it `YTDownloader`, choose **Private**, and click **Create repository**.
3. **Upload the project**: on the new repo page click **uploading an existing file**. Open the unzipped `YTDownloader` folder on your computer, select **everything inside it**, and drag it into the browser. Click **Commit changes**.
   * Check that a `.github` folder appears in the repo. On Mac, hidden folders are skipped when dragging. If it's missing: click **Add file > Create new file**, type `.github/workflows/build.yml` as the name, paste the contents of that file, and commit.
4. **Add your signing key** (so future updates install over the old app): open `signing-secrets.txt` (sent separately, never upload it). In the repo go to **Settings > Secrets and variables > Actions > New repository secret** and create the two secrets it lists.
5. **Build**: go to the **Actions** tab, click **Build APK**, then **Run workflow**. Wait about 5 to 10 minutes for the green tick.
6. **Download**: click the finished run, scroll to **Artifacts**, and download `YTDownloader-apks`. Unzip it.
7. **Install**: send `app-arm64-v8a-release.apk` to your phone (almost every phone since 2017 uses this one; very old phones need `armeabi-v7a`). Open it and allow "Install unknown apps" when asked.

Every time you change the code on GitHub, a new APK is built automatically.

## Or build with Android Studio

Install Android Studio, choose **Open**, pick this folder, wait for setup, then **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.

---

## How it keeps working for years

* **The engine (yt-dlp) updates itself** once a day on app launch, and you can tap **Update now** any time.
* If downloads stop working, turn on **Use Nightly engine**. Fixes arrive there first.
* YouTube now requires a JavaScript engine to unlock video formats. This app bundles **QuickJS** for that, which many Android downloaders lack.

### Occasional maintenance (about once a year or two)

Sometimes yt-dlp needs a newer Python than the one built into the engine library. When that happens:

1. Check the latest version of `io.github.junkfood02.youtubedl-android` on Maven Central.
2. Change `ytdlVersion` in `app/build.gradle.kts` to that version.
3. Optionally replace `app/src/main/jniLibs/*/libqjs.so` with newer QuickJS-NG binaries from github.com/quickjs-ng/quickjs/releases (`qjs-linux-aarch64` goes in `arm64-v8a`, `qjs-linux-armv7` in `armeabi-v7a`, `qjs-linux-x86_64` in `x86_64`, each renamed to `libqjs.so`).
4. Increase `versionCode` by 1, commit, and install the new APK.

---

## Security

| Area | What the app does |
| --- | --- |
| Network | HTTPS only. Plain HTTP is blocked by `network_security_config.xml`. |
| Certificates | Only Android's built-in trusted certificates. User-installed certificates are ignored, which blocks man-in-the-middle interception. |
| Engine updates | Accepted only from official `github.com/yt-dlp/` releases, verified against the official SHA-256 checksum file, size-limited, and self-tested. If anything fails, the old engine is kept. |
| Links | Only `youtube.com` and `youtu.be` links are accepted, rebuilt as clean `https` links. Shared text is checked twice (screen and service). |
| Engine options | `--ignore-config` so no config file can inject commands; links are passed as plain arguments, never through a shell. |
| Exposure | No open ports or servers. Only the Share target is exposed to other apps. The download service is private. |
| Data | Backups disabled. Nothing is sent anywhere except YouTube and GitHub (for updates). |
| Permissions | Internet, notifications, background download, and storage only on Android 9 and older. |

Note: the network rules above cover the app's own connections. The engine (yt-dlp) runs in its own Python process, which always verifies HTTPS certificates using its bundled certificate list.

### Bundled QuickJS checksums (v0.17.0)

```
3372133484edf50a69f3c67903af41206d22a061e930e3cfb63269272ef56d2e  arm64-v8a/libqjs.so    (qjs-linux-aarch64)
dbda6e499471c675bd991dbc477f14d6134c182409d15047e9b63e3df7bc3e64  armeabi-v7a/libqjs.so  (qjs-linux-armv7)
0bfc02511a9f549c28b53880d988fc7cd5d361e90c5e8afdfcd7dc6774ceace5  x86_64/libqjs.so       (qjs-linux-x86_64)
```

---

Downloading may break YouTube's Terms of Service. Keep it to personal use and videos you have the right to save.
